import { Mail, Phone, Linkedin, Globe, MapPin, Briefcase, Award, GraduationCap, Users, Code, Palette, Lightbulb, Download } from 'lucide-react';

export default function App() {
  const handleDownloadPDF = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      {/* Download Button - Hidden in Print */}
      <div className="max-w-[900px] mx-auto mb-6 print:hidden">
        <button
          onClick={handleDownloadPDF}
          className="flex items-center gap-2 bg-[#F9C74F] hover:bg-[#F9C74F]/90 text-[#2C3E50] font-semibold px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
        >
          <Download className="w-5 h-5" />
          Download as PDF
        </button>
      </div>

      <div className="max-w-[900px] mx-auto bg-white shadow-xl rounded-2xl overflow-hidden print:shadow-none print:rounded-none">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-[#2C3E50] via-[#34495E] to-[#2C3E50] text-white px-12 py-12 overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#F9C74F]/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#F9C74F]/10 rounded-full blur-3xl -ml-24 -mb-24"></div>
          <div className="absolute top-1/2 right-1/4 w-32 h-32 bg-white/5 rounded-full"></div>
          <div className="absolute bottom-1/4 right-1/3 w-20 h-20 bg-white/5 rounded-full"></div>
          <div className="relative z-10">
            <h1 className="text-5xl font-bold tracking-tight mb-4">Jannaee Sick</h1>
            <div className="h-1 w-32 bg-[#F9C74F] mb-6 rounded-full"></div>
            <div className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F9C74F]/20 flex items-center justify-center">
                  <Phone className="w-4 h-4 text-[#F9C74F]" />
                </div>
                <span>984-220-5585</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F9C74F]/20 flex items-center justify-center">
                  <Mail className="w-4 h-4 text-[#F9C74F]" />
                </div>
                <span>jannaee@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F9C74F]/20 flex items-center justify-center">
                  <Linkedin className="w-4 h-4 text-[#F9C74F]" />
                </div>
                <span>linkedin.com/in/jannaee</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F9C74F]/20 flex items-center justify-center">
                  <Globe className="w-4 h-4 text-[#F9C74F]" />
                </div>
                <span>jannaee.github.io</span>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Summary */}
        <div className="px-12 py-8 bg-gradient-to-br from-blue-50/30 via-purple-50/20 to-pink-50/30">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#F9C74F] flex items-center justify-center flex-shrink-0 mt-1 shadow-lg">
              <Lightbulb className="w-6 h-6 text-[#2C3E50]" />
            </div>
            <p className="text-[#2C3E50] leading-relaxed pt-2">
              UX/UI Designer and Front-end Engineer with 7+ years building user-centered web applications. Strong foundation in both design thinking and technical implementation, with expertise in JavaScript frameworks, design systems, and accessibility. Eager to explore conversational UI, AI visualization, and ethical design patterns and emerging AI technology.
            </p>
          </div>
        </div>

        {/* Skills */}
        <div className="px-12 py-8">
          <div className="flex items-center gap-3 mb-6">
            <Palette className="w-7 h-7 text-[#2C3E50]" />
            <h2 className="text-3xl font-bold text-[#2C3E50] tracking-tight">Skills</h2>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-gradient-to-br from-cyan-50 via-blue-50/50 to-purple-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">UX/UI Design</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                User Research | Wireframing | Prototyping | Usability Testing | Information Architecture | User Personas | Journey Mapping | Accessibility Design (WCAG) | Design Systems | Interaction Design
              </p>
            </div>
            <div className="bg-gradient-to-br from-orange-50/50 via-pink-50/50 to-purple-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">Design Tools</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                Figma, Figma Make | Adobe Creative Suite (Illustrator, Photoshop, InDesign, Adobe XD)
              </p>
            </div>
            <div className="bg-gradient-to-br from-pink-50/50 via-purple-50/50 to-blue-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">Front-end Development</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                HTML5 | CSS3 | JavaScript | TypeScript | React | Angular | Node.js | Responsive Design
              </p>
            </div>
            <div className="bg-gradient-to-br from-yellow-50/50 via-orange-50/50 to-pink-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">Design Methodologies</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                Enterprise Design Thinking | User-Centered Design | Agile/Scrum | Design Sprints | A/B Testing
              </p>
            </div>
            <div className="bg-gradient-to-br from-blue-50/50 via-cyan-50/50 to-teal-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">Collaboration Tools</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                Storybook | GIT | Jira | Confluence | Miro | Abstract
              </p>
            </div>
            <div className="bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-red-50/50 p-5 rounded-2xl shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <span className="bg-[#F9C74F] text-[#2C3E50] text-xs font-semibold px-3 py-1 rounded-full">Emerging AI</span>
              </div>
              <p className="text-[#2C3E50]/80 text-sm leading-relaxed">
                Claude | ChatGPT | Midjourney | Veo | Figma Make
              </p>
            </div>
          </div>
        </div>

        {/* Professional Experience */}
        <div className="px-12 py-8 bg-gradient-to-br from-gray-50/50 to-transparent">
          <div className="flex items-center gap-3 mb-8">
            <Briefcase className="w-7 h-7 text-[#2C3E50]" />
            <h2 className="text-3xl font-bold text-[#2C3E50] tracking-tight">Professional Experience</h2>
          </div>
          
          <div className="space-y-6 relative before:absolute before:left-0 before:top-0 before:bottom-0 before:w-0.5 before:bg-gradient-to-b before:from-[#F9C74F] before:via-[#F9C74F]/50 before:to-transparent">
            {/* ARA */}
            <div className="pl-8 relative before:absolute before:left-[-4px] before:top-2 before:w-2 before:h-2 before:rounded-full before:bg-[#F9C74F] before:ring-4 before:ring-white">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-[#2C3E50] text-lg">UX/UI Designer & Front End Engineer</h3>
                  <p className="text-[#2C3E50]/70 font-medium">Applied Research Associates, Raleigh NC</p>
                </div>
                <span className="text-sm text-[#2C3E50] bg-[#F9C74F] px-3 py-1 rounded-full font-medium whitespace-nowrap">March 2024 - Present</span>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-1.5 text-sm text-[#2C3E50]/80">
                <li>Lead UX/UI design for native and web applications supporting military and defense planning operations, translating complex operational requirements into intuitive user experiences</li>
                <li>Conduct comprehensive user research, cognitive task analyses, and usability testing with end-users to validate design decisions and iterate on solutions</li>
                <li>Create wireframes, mockups, high-fidelity prototypes, and design specifications that communicate design vision to stakeholders and development teams</li>
                <li>Design and maintain design systems ensuring consistency across multiple applications and platforms</li>
                <li>Implement front-end solutions using modern JavaScript frameworks</li>
                <li>Apply software development best practices including code reviews, version control with GIT, and agile methodologies</li>
              </ul>
            </div>

            {/* Turbonomic */}
            <div className="pl-8 relative before:absolute before:left-[-4px] before:top-2 before:w-2 before:h-2 before:rounded-full before:bg-[#F9C74F] before:ring-4 before:ring-white">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-[#2C3E50] text-lg">Front End Engineer</h3>
                  <p className="text-[#2C3E50]/70 font-medium">Turbonomic at IBM, Raleigh NC</p>
                </div>
                <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium whitespace-nowrap">February 2022 - November 2023</span>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-1.5 text-sm text-[#2C3E50]/80">
                <li>Refactored API calls across shared React and Angular services using a common service layer, reducing code duplication by 30% and improving maintainability</li>
                <li>Developed production features using JavaScript, TypeScript, React, and Angular within a Linux-based development environment</li>
                <li>Conducted rigorous peer code reviews ensuring UI integrity, backward compatibility, and adherence to enterprise standards</li>
                <li>Collaborated with cross-functional teams including product management, engineering, and QA in agile environment</li>
              </ul>
            </div>

            {/* Red Hat */}
            <div className="pl-8 relative before:absolute before:left-[-4px] before:top-2 before:w-2 before:h-2 before:rounded-full before:bg-[#F9C74F] before:ring-4 before:ring-white">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-[#2C3E50] text-lg">Front End Engineer</h3>
                  <p className="text-[#2C3E50]/70 font-medium">Red Hat Marketplace at IBM, Raleigh NC</p>
                </div>
                <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium whitespace-nowrap">September 2019 - February 2022</span>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-1.5 text-sm text-[#2C3E50]/80">
                <li>Led design critique sessions and established design standards that improved UI consistency across the Red Hat Marketplace ecosystem</li>
                <li>Spearheaded accessibility initiatives, conducting comprehensive audits and implementing WCAG 2.1 AA compliance updates across Angular and React applications</li>
                <li>Developed custom HTML/JavaScript/React components based on Carbon Design System, deployed via Storybook for use by 12 cross-functional development teams</li>
                <li>Engineered responsive, accessible transactional email templates serving 90% of internal software vendors</li>
              </ul>
            </div>

            {/* MedThink */}
            <div className="pl-8 relative before:absolute before:left-[-4px] before:top-2 before:w-2 before:h-2 before:rounded-full before:bg-[#F9C74F] before:ring-4 before:ring-white">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-[#2C3E50] text-lg">Front End Developer</h3>
                  <p className="text-[#2C3E50]/70 font-medium">MedThink Inc., Raleigh NC</p>
                </div>
                <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium whitespace-nowrap">January 2019 - September 2019</span>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-1.5 text-sm text-[#2C3E50]/80">
                <li>Developed and maintained responsive web applications using modern JavaScript frameworks, consistently meeting project deadlines</li>
                <li>Improved application performance by 20% through systematic optimization, directly enhancing user experience and satisfaction</li>
                <li>Collaborated with UX designers to translate wireframes and prototypes into production-ready interfaces</li>
              </ul>
            </div>

            {/* EverBank */}
            <div className="pl-8 relative before:absolute before:left-[-4px] before:top-2 before:w-2 before:h-2 before:rounded-full before:bg-[#F9C74F] before:ring-4 before:ring-white">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <div>
                  <h3 className="font-bold text-[#2C3E50] text-lg">Digital UX Designer</h3>
                  <p className="text-[#2C3E50]/70 font-medium">EverBank, Jacksonville FL</p>
                </div>
                <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium whitespace-nowrap">September 2009 - December 2014</span>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-1.5 text-sm text-[#2C3E50]/80">
                <li>Pioneered design and development of one of the financial industry's first responsive banking websites, creating seamless mobile experiences for 3,500+ clients</li>
                <li>Conducted user research and usability studies to identify pain points and opportunities for interface improvements</li>
                <li>Established and maintained design pattern libraries ensuring consistency across digital touchpoints</li>
                <li>Designed comprehensive digital interfaces and interactive elements for web applications</li>
                <li>Collaborated with marketing, SEO specialists, and development teams to create intuitive interfaces that improved user satisfaction and reduced bounce rates by 25%</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Community Leadership */}
        <div className="px-12 py-8">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-7 h-7 text-[#2C3E50]" />
            <h2 className="text-3xl font-bold text-[#2C3E50] tracking-tight">Community Leadership & Speaking</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="p-5 bg-gradient-to-br from-cyan-50/50 via-blue-50/30 to-purple-50/30 rounded-2xl shadow-sm">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <h3 className="font-bold text-[#2C3E50]">P-TECH Technical Manager</h3>
                <span className="text-xs text-[#2C3E50] bg-[#F9C74F] px-2 py-1 rounded-full font-medium">IBM, August 2021</span>
              </div>
              <p className="text-sm text-[#2C3E50]/80">Led high-performing team of interns to second place in People's Choice awards, mentoring on design thinking and agile methodologies while competing against 1,000 students nationwide</p>
            </div>
            <div className="p-5 bg-gradient-to-br from-orange-50/50 via-pink-50/30 to-purple-50/30 rounded-2xl shadow-sm">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <h3 className="font-bold text-[#2C3E50]">Red Hat Education Guild Program Lead</h3>
                <span className="text-xs text-[#2C3E50] bg-[#F9C74F] px-2 py-1 rounded-full font-medium">IBM, February 2022</span>
              </div>
              <p className="text-sm text-[#2C3E50]/80">Coordinated technical seminar series covering UX/UI best practices, accessibility standards, and emerging design trends for developers, designers, and product leaders</p>
            </div>
            <div className="p-5 bg-gradient-to-br from-pink-50/50 via-purple-50/30 to-blue-50/30 rounded-2xl shadow-sm">
              <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
                <h3 className="font-bold text-[#2C3E50]">IBM Aspiring Leaders Development Program</h3>
                <span className="text-xs text-[#2C3E50] bg-[#F9C74F] px-2 py-1 rounded-full font-medium">IBM, November 2020</span>
              </div>
              <p className="text-sm text-[#2C3E50]/80">Selected by senior leadership for exclusive leadership training academy based on pioneering initiatives in diversity, team-building, and design advocacy</p>
            </div>
            <div className="p-5 bg-gradient-to-br from-yellow-50/50 via-orange-50/30 to-pink-50/30 rounded-2xl shadow-sm">
              <h3 className="font-bold text-[#2C3E50] mb-2">Speaker, All Things Open Conference</h3>
              <ul className="text-sm text-[#2C3E50]/80 space-y-1">
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#F9C74F] mt-1.5 flex-shrink-0"></span>
                  <span>2020: "Crushing React Bugs with Enzyme & Jest"</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#F9C74F] mt-1.5 flex-shrink-0"></span>
                  <span>2019: "Raising a Minority Child with STEM Skills"</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Awards */}
        <div className="px-12 py-8 bg-gradient-to-br from-blue-50/30 via-purple-50/20 to-pink-50/30">
          <div className="flex items-center gap-3 mb-6">
            <Award className="w-7 h-7 text-[#2C3E50]" />
            <h2 className="text-3xl font-bold text-[#2C3E50] tracking-tight">Awards & Recognition</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-full bg-[#F9C74F] flex items-center justify-center flex-shrink-0 shadow-md">
                  <Award className="w-6 h-6 text-[#2C3E50]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2C3E50] mb-1">People's Choice Award</h3>
                  <span className="text-xs text-[#2C3E50] bg-[#F9C74F]/30 px-2 py-1 rounded-full font-medium">2020</span>
                  <p className="text-sm text-[#2C3E50]/80 mt-2">Recognized for contributions to diversity, developer success, and educational excellence at IBM</p>
                </div>
              </div>
            </div>
            <div className="p-5 bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-full bg-[#F9C74F] flex items-center justify-center flex-shrink-0 shadow-md">
                  <Code className="w-6 h-6 text-[#2C3E50]" />
                </div>
                <div>
                  <h3 className="font-bold text-[#2C3E50] mb-1">Code.gov Hackathon Winner</h3>
                  <span className="text-xs text-[#2C3E50] bg-[#F9C74F]/30 px-2 py-1 rounded-full font-medium">2019</span>
                  <p className="text-sm text-[#2C3E50]/80 mt-2">First place for exceptional problem-solving and user-focused bug resolution</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Education */}
        <div className="px-12 py-8">
          <div className="flex items-center gap-3 mb-6">
            <GraduationCap className="w-7 h-7 text-[#2C3E50]" />
            <h2 className="text-3xl font-bold text-[#2C3E50] tracking-tight">Education & Certifications</h2>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-cyan-50/50 to-purple-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">IDEO University Creative Leadership</span> <span className="text-[#2C3E50]/70">| IDEO</span></span>
              <span className="text-sm text-[#2C3E50] bg-[#F9C74F] px-3 py-1 rounded-full font-medium">2026</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-orange-50/50 to-pink-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">Enterprise Design Thinking Practitioner</span> <span className="text-[#2C3E50]/70">| IBM</span></span>
              <span className="text-sm text-[#2C3E50] bg-[#F9C74F] px-3 py-1 rounded-full font-medium">2023</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-purple-50/50 to-blue-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">Accessibility Advocate</span> <span className="text-[#2C3E50]/70">| IBM</span></span>
              <span className="text-sm text-[#2C3E50] bg-[#F9C74F] px-3 py-1 rounded-full font-medium">2020</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-pink-50/50 to-yellow-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">IBM Agile Explorer Certification</span> <span className="text-[#2C3E50]/70">| IBM</span></span>
              <span className="text-sm text-[#2C3E50] bg-[#F9C74F] px-3 py-1 rounded-full font-medium">2019</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-blue-50/50 to-purple-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">Google & Udacity Mobile Web Specialist Certification</span></span>
              <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium">Sept 2018</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gradient-to-br from-purple-50/50 to-pink-50/30 rounded-2xl shadow-sm">
              <span className="text-sm text-[#2C3E50]"><span className="font-bold">Bachelor of Graphic Design</span> <span className="text-[#2C3E50]/70">| University of North Florida</span></span>
              <span className="text-sm text-[#2C3E50]/70 bg-gray-100 px-3 py-1 rounded-full font-medium">Dec 2005</span>
            </div>
          </div>
        </div>

        {/* Additional Information */}
        <div className="px-12 py-8 from-gray-50 to-blue-50/30">
        </div>
      </div>
    </div>
  );
}