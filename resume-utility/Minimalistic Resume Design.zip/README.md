
  # Minimalistic Resume Design

  This is a code bundle for Minimalistic Resume Design. The original project is available at https://www.figma.com/design/CxGp2FQ7yNwdGGbs3cLrCh/Minimalistic-Resume-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  